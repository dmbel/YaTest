package ru.dmbel.yandextest.data.dataobjects;

import java.io.Serializable;

/**
 * Created by dm on 21.04.16.
 */
public class CoverSet implements Serializable {
    public String big;
    public String small;
}
